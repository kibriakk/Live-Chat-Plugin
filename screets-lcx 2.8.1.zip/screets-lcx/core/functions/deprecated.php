<?php
/**
 * SCREETS © 2018
 *
 * Deprecated framework functions from past framework versions. You shouldn't use these
 * functions and look for the alternatives instead. The functions will be removed in a later version.
 *
 * SCREETS, d.o.o. Sarajevo. All rights reserved.
 * This  is  commercial  software,  only  users  who have purchased a valid
 * license  and  accept  to the terms of the  License Agreement can install
 * and use this program.
 *
 * @package LiveChatX
 * @author Screets
 *
 */

/**
 *
 * ___
 *
 * @since 1.0.0
 * @deprecated 1.0.0
 *
 */
/*function lcx_() {
  _deprecated_function( __FUNCTION__, '1.0.0' );
}*/